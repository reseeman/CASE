﻿using System.Windows;
using System.Windows.Input;
using VendMach.Pages;
using VendMach.Scripts;

namespace VendMach
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            //инициализация модели БД
            ConnectHelper.entObj = new VendMachEntities();

            //инициализация страниц
            FrameApp.frmObj = frmMain;

            //открытие страницы Пользователя
            frmMain.Navigate(new UserUI());
        }

        //Метод сворачивания окна (приложения)
        private void btnMin_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        //Метод разворачивания окна на весь экран и возварщения его в нормальное состояние 
        private void btnMax_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState != WindowState.Maximized) WindowState = WindowState.Maximized;
            else WindowState = WindowState.Normal;
        }

        //Меод закрытия приложения
        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        //Метод перетаскиваня окна по экрану
        private void brDrop_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            //При условии удержания ЛКМ
            if (e.ChangedButton == MouseButton.Left)
            {
                DragMove();
            }
        }
    }
}
